# Lemon_Kumquat_Robust > 2025-04-24 1:49pm
https://universe.roboflow.com/mehdi-cko8a/lemon_kumquat_robust-jf4n3

Provided by a Roboflow user
License: CC BY 4.0

